#!/bin/bash
cd /home/site/wwwroot
npm start